<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="earth" tilewidth="8" tileheight="8" tilecount="576" columns="36">
 <image source="../../../../Downloads/kenney_monochromerpg/Dot Matrix/Tilemap/tilemap.png" width="288" height="135"/>
</tileset>
