<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="farm" tilewidth="8" tileheight="8" tilecount="544" columns="34">
 <image source="../../Downloads/kenney_monochromerpg/Dot Matrix/Tilemap/tilemap_packed.png" width="272" height="128"/>
</tileset>
